import React from "react";
import Director from "./components/director";

function App() {

  return (
    <div className="App">
    <Director/>
    </div>
  );
}

export default App;
