import React from "react";
import {BrowserRouter as Router, Route, Routes, Link} from "react-router-dom";
import Home from "./home";
import Login from "./login";
import Register from "./register";
import UserProfile from "./user_profile";
import CarrierProfile from "./carrier_profile";
import EmployeeProfile from "./employee_profile";
import AdminProfile from "./admin_profile";

const Director = () => {

    return (
        <Routes>
            <Route exact path="/" element={<Home/>}/>
            <Route exact path="/login" element={<Login/>}/>
            <Route exact path="/register" element={<Register/>}/>   
            <Route exact path="/user_profile" element={<UserProfile/>}/>
            <Route exact path="/carrier_profile" element={<CarrierProfile/>}/>
            <Route exact path="/employee_profile" element={<EmployeeProfile/>}/>
            <Route exact path="/admin_profile" element={<AdminProfile/>}/>     
        </Routes>

    );
}

export default Director;