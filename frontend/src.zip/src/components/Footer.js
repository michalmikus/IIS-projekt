import tram_img from './tram_picture.png'

const Footer = () => {
    return (
        <footer>
        <img src={tram_img} alt="tramvaj"></img>
      </footer>
    )
}

export default Footer;
